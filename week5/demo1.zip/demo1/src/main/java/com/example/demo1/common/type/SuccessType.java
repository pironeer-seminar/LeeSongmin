package com.example.demo1.common.type;

public interface SuccessType {
    String getCode();
    String getMessage();
}
