package com.example.demo1.post.entity;

public enum PostStatus {
    PUBLIC, PRIVATE;
}
