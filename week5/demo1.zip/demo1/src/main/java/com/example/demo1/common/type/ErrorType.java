package com.example.demo1.common.type;

public interface ErrorType {
    String getCode();
    String getMessage();
}
